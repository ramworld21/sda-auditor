import fs from "fs";
import { chromium } from "playwright";

export async function auditSite(url) {
  const browser = await chromium.launch();
  const page = await browser.newPage();
  await page.goto(url, { waitUntil: "networkidle" });

  const title = await page.title();
  const snapPath = `reports/snap-${Date.now()}.png`;
  await page.screenshot({ path: snapPath, fullPage: true });

  const result = { url, title, snapPath, timestamp: new Date().toISOString() };
  fs.writeFileSync("reports/audit.json", JSON.stringify(result, null, 2));

  console.log("Audit done. Report saved in reports/audit.json");
  await browser.close();
}


import { generateHTMLReport } from "../utils/reporter.js";

// Wrap original auditSite to add HTML report
const originalAuditSite = auditSite;
export async function auditSite(url) {
  const browser = await chromium.launch();
  const page = await browser.newPage();
  await page.goto(url, { waitUntil: "networkidle" });

  const title = await page.title();
  const snapPath = `reports/snap-${Date.now()}.png`;
  await page.screenshot({ path: snapPath, fullPage: true });

  const result = { url, title, snapPath, timestamp: new Date().toISOString() };
  fs.writeFileSync("reports/audit.json", JSON.stringify(result, null, 2));

  // Generate HTML report
  generateHTMLReport(result);

  console.log("Audit done. JSON + HTML reports generated.");
  await browser.close();
}
